#!/usr/bin/python3.4


# This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>


# dht22spi.py
#
# Read dht22 sensor using Raspberry Pi spi
#
# Daniel Perron
# 15 February 2014
# 

# August 2016
# add delay on startup for DHT11
# change output format for DHT11
# add flag to select DHT22 or DHT11



IsDHT11 = False


import spidev
import time
spi = spidev.SpiDev()
speed=500000
spi.open(32766,0)
spi.max_speed_hz=speed
Counter=0;

Bits = [ 128, 64, 32, 16, 8, 4, 2, 1]
DHT22Reg = [0,0,0,0,0]

#add 18 ms for DHT11 sensor
#ok 10ms + 18 ms = ~ 30 ms  should be good enough

MaxBits = 0.030 * speed


ArraySize = int(MaxBits / 8)
TotalBits = ArraySize * 8

#print("Array Size=",ArraySize)

D = bytearray(ArraySize)

LastIndex=int(0);


def GetBit(index):
  global Data
  global bits
  byteIndex = int(index / 8)
  if (Data[byteIndex] &  Bits[index % 8]) == 0:
    return False
  return True


def GetNextDelay():
  global LastIndex
  Deltaus=9999
  if LastIndex  >= TotalBits:
     return int(0)
  Index = int(LastIndex)
  LastBit = GetBit(Index)
  while Index<TotalBits:
    if not (GetBit(Index) == LastBit):
      Delta = Index - LastIndex
      Deltaus = Delta * 1000000 / speed
      LastIndex = int(Index)
      return int(Deltaus)
    Index = int(Index +1)
   

# set first 1.5 ms Low and the rest high
# set 18ms for dht11

if IsDHT11:
  End = (0.018 * speed)/8
else:
  End = (0.0015 * speed)/8

#print "End=", End, "\n"


for i in range(ArraySize):
 if i > End:
   D[i] = 255
 else:
   D[i] = 0

Data = list(D)
Data = spi.xfer2(Data)


#print Data

#ok decode 

#first get rid off start
GetNextDelay()

#now get rid off wait
GetNextDelay()

#now get rid off Ack
GetNextDelay()

#and the the high Ack
GetNextDelay()

for Idx in range(5):
  DHT22Reg[Idx]=0
  for bitidx in range(8):
  
    #low parts
    GetNextDelay()

    #read High Parts
    a = GetNextDelay()

    delai = a

    if delai < 12:
     print("error")
     break

    if delai > 50:
      DHT22Reg[Idx] |= Bits[bitidx]     

#print "DHT22Reg = ", DHT22Reg

Checksum = 0;
for Idx in range(4):
  Checksum += DHT22Reg[Idx]

Checksum %= 256
#print "CheckSum= ", Checksum

if Checksum == DHT22Reg[4]:
   if IsDHT11 :
       Temp = DHT22Reg[2]
       Humidity= DHT22Reg[0]
   else:
       Temp= ((DHT22Reg[2] & 127) * 256  + DHT22Reg[3]) / 10.0
       if (DHT22Reg[2] & 128) == 128:
           Temp = -Temp
       Humidity= (DHT22Reg[0] * 256 + DHT22Reg[1]) / 10.0 
   print( " Temperature = " , Temp, "Celsius")
   print( " Humidity    = "  , Humidity, "%")
else:
   print( "Data = ", DHT22Reg," Checksum = ", Checksum)
   print( "Unable to read sensor (bad checksum).\n")
