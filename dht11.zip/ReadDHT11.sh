#!/bin/bash

# scan all IIO devices to get the humidity one

SCAN_PATH="/sys/bus/iio/devices/iio:device"
SCAN_NAME="humidity_sensor"
SCAN_SUFFIX="name"



function convert(){
  printf "%d.%1d" $(($1 / 1000)) $(((($1 % 1000)+50)/100))  $2
}






FILE=${SCAN_PATH}"*/"${SCAN_SUFFIX}

# scan for all IIO device to find the DHT22

for f in $FILE
do
  #check  inf name contains SCAN_NAME
   if grep -q $SCAN_NAME $f;
    then
     IIO_PATH=${f%$SCAN_SUFFIX}
     DEVICE=${f#$SCAN_PATH}
     echo -ne "sensor  #"; echo ${DEVICE%"/"$SCAN_SUFFIX};
     T=$(cat "${IIO_PATH}in_temp_input");
     echo -ne "temperature ="; convert $T ; echo -ne  "C (" ;  convert $((T * 9 / 5 + 32000)); 
     echo "F)";
     echo -ne "humidity    =";convert $(cat "${IIO_PATH}in_humidityrelative_input");
     printf "%%\n\n";
   fi
done
